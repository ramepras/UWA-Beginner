(function () {
    'use strict';
    var MyWidget = {
        tableCreated: false,
        onLoad: function () {
            if (MyWidget.tableCreated) {
                return;
            }
            var posts = 'https://jsonplaceholder.typicode.com/posts/';
            var users = 'https://jsonplaceholder.typicode.com/users/';
            MyWidget.getData(users)
                .then(function (response) {
                    const data = [];
                    response.forEach(function (element) {
                        element.city = element.address.city;
                        element.street = element.address.street;
                        element.suite = element.address.suite;
                        element.zipcode = element.address.zipcode;
                        console.log(element);
                        element.company = element.company.name;
                        data.push(element);
                    });
                    const myDataGrid = new UWA.Controls.DataGrid({
                        id: 'my-DataGrid',
                        className: 'my-dataGrid',
                        columns: myColumns,
                        data: data,
                        sortable: widget.getBool('sortable')
                    }).inject(widget.body);
                    myDataGrid.addScroller();
                    MyWidget.tableCreated = true;
                })
                .catch(function (error) {
                    console.error(error);
                });
        },
        getData: function (url) {
            return new UWA.Promise(function (resolve, reject) {
                UWA.Data.request(url, {
                    method: 'GET',
                    type: 'json',
                    onComplete: function (response) {
                        resolve(response);
                    },
                    onFailure: function (response) {
                        reject(response);
                    },
                    onTimeout: function (response) {
                        reject(response);
                    }
                });
            });
        },
    };
    document.addEventListener('DOMContentLoaded', function () {
        MyWidget.onLoad();
    });
}());