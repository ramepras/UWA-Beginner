define('MyCompany/Controls/Button', [
    'UWA/Core',
    'UWA/Controls/Abstract',
], function (Core, Abstract) {

    // NOTE: add use strict for good practice and
    // avoid global usage or missing var.
    'use strict';

    /*
      Class: MyCompany.Controls.Button

        Display a customizable button.

      Extends:
        <UWA.Controls.Abstract>
    */
    var Button = Abstract.extend({

        /* Group: Properties */

        /*
          Property: defaultOptions
            The default controls options.
        */
        // NOTE: Use defaultOptions to define the default value of options.
        defaultOptions: {
            text: '',
            className: 'MyCompany-button',
        },

        /* Group: Methods */

        /*
          Method: init

            Set the options for the current controls instance,
            creates observers and elements object.

          Parameters:
            * Object options: options hash or a option/value pair.

          Returns:
            * Nothing.
        */
        init: function (options) {

            // NOTE: if you override init, you may need to call
            // the parent method to handle options and events.
            this._parent(options);

            // NOTE: Isolate your DOM creation into
            // a sub method that you call inside the init.
            this.buildSkeleton();
        },

        buildSkeleton: function () {

            var options = this.options;

            // NOTE: Create DOM for the control using <UWA.createElement>
            // then store it into this.elements.container.
            this.elements.container = Core.createElement('a', {
                'class': options.className,

                // NOTE: use html options instead of raw HTML
                html: {
                    tag: 'span',
                    text: options.text
                },

                // NOTE: Style your basic control design inside JavaScript
                // not in a separate stylesheet for good practice. It is still
                // possible to overide it inside the widget using stylesheet or style tag
                // later for more customizations.
                styles: {
                    padding: '5px',
                    background: 'blue',
                    color: 'white',

                    // NOTE: UWA supports CSS3, and will add prefixes, if required, using
                    // feature detection.
                    borderRadius: '5px',
                    boxShadow: '5px 5px 2px #888'
                },

                // NOTE: Plug the events using <UWA.Controls.Abstract.dispatchAsEventListener>
                // to allow event attachement from contrusctor and default events.
                events: {
                    click: this.dispatchAsEventListener('onClick'),
                    mouseover: this.dispatchAsEventListener('onMouseOver'),
                    mouseleave: this.dispatchAsEventListener('onMouseLeave'),
                }
            });
        },

        /* Group: Events methods */

        // NOTE: Add some default event behavior to the control.
        // These will be triggered because we are using <UWA.Controls.Abstract.dispatchAsEventListener>.

        onClick: function () {
            this.elements.container.addClassName('clicked');
        },

        onMouseOver: function () {
            this.elements.container.addClassName('over');
        },

        onMouseLeave: function () {
            this.elements.container.removeClassName('over');
        },
    });

    // Create the Namespace
    MyCompany = window.MyCompany = window.MyCompany || {};
    MyCompany.Controls = MyCompany.Controls || {};
    MyCompany.Controls.Button = Button;

    return Button;
});