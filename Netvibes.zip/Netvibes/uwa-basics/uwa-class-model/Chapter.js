define('Chapter', ['UWA/Class/Model'], function (Model) {
    var Chapter = UWA.Class.Model.extend({
        validate: function (attrs, options) {
            
            if (attrs.end < attrs.start) {
                return "can't end before it starts";
            }
        }
    });
    return Chapter;
});