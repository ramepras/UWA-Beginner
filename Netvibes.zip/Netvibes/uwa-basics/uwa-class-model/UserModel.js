define('UserModel', ['UWA/Class/Model'], function (Model) {
    // Define a new model
    var UserModel = Model.extend({
        defaults: {
            id: null,
            name: '',
            email: ''
        },
        setup: function () {
            UWA.log('This model has been initialized.');
        },

        url: 'https://httpbin.org/anything',
        sync: function (method, model, options) {
            options || (options = {});
            switch (method) {
                case 'create':
                    options.url = this.url + '/post';
                    options.method = 'POST';
                    options.data = JSON.stringify(model.toJSON());
                    break;
                case 'read':
                    options.url = this.url + '/get?id=' + model.get('id');
                    options.method = 'GET';
                    break;
                case 'update':
                    options.url = this.url + '/put?id=' + model.get('id');
                    options.method = 'PUT';
                    options.data = JSON.stringify(model.toJSON());
                    break;
                case 'delete':
                    options.url = this.url + '/delete?id=' + model.get('id');
                    options.method = 'DELETE';
                    break;
            }

            options.success = function (data) {
                console.log('Success: ', data);
            };

            options.error = function (xhr) {
                console.log('Error: ', xhr.responseText);
            };

            return Model.prototype.sync.call(this, method, model, options);
        }
    });
    return UserModel;
});
