define('Book', ['UWA/Class/Model'], function(Model){
    var Book = Model.extend({});
    return Book;
});