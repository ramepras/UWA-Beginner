define('User',
    ['UWA/Class/Model',
        'UWA/Class/Debug',
        'UWA/String'],
    function (Model, Debug, UWAString) {
        var User = UWA.Class.Model.extend(Debug, {
            validate: function (attributes) {
                // Here some validation code of the attributes
                // so that we make sure data is valid before save()...
            },
            defaults: {
                'name': 'Type your name', // ok, this is obvious :)
                'street': 'Type your street',
                'city': 'Type your city',
                'state': 'Type your state code',
                'zipCode': 'Type your zip code'
            },
            setup: function () {
                UWA.log("Widget !!" + this.name);
            }
        });
        return User;
    });

