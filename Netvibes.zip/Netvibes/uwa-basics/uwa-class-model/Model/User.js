define('User', ['UWA/Class/Model'], function (Model) {
    var User = Model.extend({
        defaults: {
            id: null,
            name: '',
            username: '',
            email: '',
            address: {
                street: '',
                suite: '',
                city: '',
                zipcode: '',
                geo: {
                    lat: '',
                    lng: ''
                }
            },
            phone: '',
            website: '',
            company: {
                name: '',
                catchPhrase: '',
                bs: ''
            }
        }
    });
    return User;
});


