define('UserModel', ['UWA/Class/Model'], function (Model) {
    // Define a new model
    var UserModel = Model.extend({
        defaults: {
            id: 1,
            name: '',
            email: ''
        },
        setup: function () {
            UWA.log('This model has been initialized.');
        },

        url: 'https://jsonplaceholder.typicode.com/users/',
        sync: function (method, model, options) {
            console.log("method:"+method);
            options || (options = {});
            var url = this.url;
            var data = JSON.stringify(model.toJSON());
            if (method === 'read') {
                url;
            } else if (method === 'create') {
                options.method = 'POST';
                options.body = data;
                url += '/post';
            } else if (method === 'update') {
                options.method = 'PUT';
                options.body = data;
                url += '/put?id=' + model.get('id');
            } else if (method === 'delete') {
                options.method = 'DELETE';
                url += '/delete?id=' + model.get('id');
            }
            options.headers = {
                'Content-Type': 'application/json'
            };

            return fetch(url, options)
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function (data) {
                    console.log('Success: ', data);
                    return data;
                })
                .catch(function (error) {
                    console.error('Error: ', error);
                    throw error;
                });
        }
    });
    return UserModel;
});
