define('Users', ['UWA.Class.Collection', 'User'], function (Collection, User) {
    var Users = Collection.extend({
        model: User,
        url: 'https://jsonplaceholder.typicode.com/users/',
    
        // Parse the response from the server to get the users data
        parse: function (response) {
            return response;
        }
    });
    return Users;
});