define('TaskList', [
    'UWA/Class',
    'UWA/Class/Debug'
], function (Class, Debug) {
    var TaskList = Class.extend(Debug, {
        init: function () {
            // Add elements storage
            this.elements = {};
        },
        addElement: function(name, value) {
            // Display debug info using log method.
            this.log(UWA.String.format('addElement name={0}, value={1}', name, value));
            this.elements[name] = value;
        },
        getElements: function() {
            return this.elements;
        }
    });
    return TaskList;
});