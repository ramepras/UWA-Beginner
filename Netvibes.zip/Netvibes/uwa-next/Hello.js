define(['axios'], function (axios) {
    // Make an API call using Axios
    axios.get('https://api.example.com/data')
      .then(function (response) {
        // Handle the API response
        console.log(response.data);
      })
      .catch(function (error) {
        // Handle errors
        console.error(error);
      });
  });
  