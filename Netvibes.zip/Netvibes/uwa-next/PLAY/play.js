(function () {
    document.addEventListener('DOMContentLoaded', function () {
        MyWidget.onLoad();
    });
}());