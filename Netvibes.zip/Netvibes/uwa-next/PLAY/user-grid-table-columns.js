const myColumns = [
    {
        "text": "ID",
        "dataIndex": "id",
        "isFixed": true,
        "noSortable": true,
        "isFirst": true
    },
    {
        "text": "Name",
        "dataIndex": "name",
        "isFixed": true
    },
    {
        "text": "Username",
        "dataIndex": "username"
    },
    {
        "text": "Email",
        "dataIndex": "email"
    },
    {
        "text": "Phone",
        "dataIndex": "phone"
    },
    {
        "text": "Web Site",
        "dataIndex": "website"
    },
    {
        "text": "City",
        "dataIndex": "city"
    },
    {
        "text": "Street",
        "dataIndex": "street"
    },
    {
        "text": "Zip Code",
        "dataIndex": "zipcode"
    },
    {
        "text": "Company",
        "dataIndex": "company"
    }
];
