define("catModule", ["domesticAnimalModule"], function(domesticAnimalModule) {
    function say() {
        console.log("meow, meow");
    }
    return {
        say: say
    }
});