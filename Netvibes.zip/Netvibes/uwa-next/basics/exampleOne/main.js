require(['/catModule'], function (catModule) {
    catModule.say();
  });
  