define("SimpleModule", {
    state: "karnataka",
    city: "bangalore"
 });

 define("FunctionModule", function () {
   
    //Do setup work here
    return {
       state: "karnataka",
       city: "bangalore"
    }
 });