define('moduleB', function() {
    function doSomething() {
      console.log('doing something');
    }
  
    return {
      doSomething: doSomething
    };
  });