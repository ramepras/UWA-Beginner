define('driverModule', ['carModule'], function(carModule) {
    function driveCar() {
      console.log('Driving a', carModule.yellowCar.color, carModule.yellowCar.make, carModule.yellowCar.model);
    }
  
    return {
      driveCar: driveCar
    };
  });