require('amd-loader');
require(['driverModule'], function (driverModule) {
  driverModule.driveCar();
});