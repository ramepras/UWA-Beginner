define('carModule', function() {
    var yellowCar = {
      make: 'Ford',
      model: 'Mustang',
      color: 'yellow'
    };
  
    return {
      yellowCar: yellowCar
    };
  });