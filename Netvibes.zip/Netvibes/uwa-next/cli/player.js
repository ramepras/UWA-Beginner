define(function (require) {
    var myteam = require("./team");
 
    return {
       myfunc: function () {
          console.log("Name: " + myteam.player + ", Country: " + myteam.team);
       }
    };
 });
