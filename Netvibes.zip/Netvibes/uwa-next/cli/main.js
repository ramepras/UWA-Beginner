var requirejs = require('requirejs');
// main.js
require('amd-loader');
require(['moduleA'], function(moduleA) {
  moduleA.doSomethingElse();
});