require('amd-loader');
define(function (require) {
    var myteam = require("./team");
    var mylogger = require("./player");
    console.log("Player Name : " + myteam.player);
    mylogger.myfunc();
 });