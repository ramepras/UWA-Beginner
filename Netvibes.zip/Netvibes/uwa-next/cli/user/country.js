define('countryModule', function() {
    var countryInfo = {
      name: 'India',
      year: '2023',
      capital: 'New Delhi'
    };
  
    return {
        countryInfo: countryInfo
    };
  });