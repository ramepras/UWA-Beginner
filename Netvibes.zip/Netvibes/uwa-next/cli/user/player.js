define('playerModule', ['countryModule'], function(countryModule) {
    function playerInfo() {
      console.log('Play for', countryModule.countryInfo.name);
    }
  
    return {
        playerInfo: playerInfo
    };
  });