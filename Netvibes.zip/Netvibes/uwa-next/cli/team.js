define({
    player: "Sachin Tendulkar",
    team : "India"
 });
 