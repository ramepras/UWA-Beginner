// Define moduleA, which depends on moduleB
define('moduleA', ['moduleB'], function(moduleB) {
  function doSomethingElse() {
    moduleB.doSomething();
  }

  return {
    doSomethingElse: doSomethingElse
  };
});