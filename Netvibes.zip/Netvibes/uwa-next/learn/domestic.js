define("domesticAnimalModule", function() {
    function eat() {
        console.log('eat');
      }
      function sleep() {
        console.log('sleep');
      }
      return {
        eat: eat,
        sleep: sleep
      };
});

define("catModule", ["domesticAnimalModule"], function(domesticAnimalModule) {
    function say() {
        domesticAnimalModule.eat();
        console.log("meow meow");
    }
    return {
        say: say
    }
});