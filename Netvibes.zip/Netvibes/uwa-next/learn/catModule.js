define("catModule", ["domesticAnimalModule"], function(domesticAnimalModule) {
    function say() {
        return "meow meow";
    }
    return {
        say: say
    }
});