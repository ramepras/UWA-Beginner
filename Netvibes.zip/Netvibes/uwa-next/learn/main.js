define(function (require) {
  console.log("start");
  require("./domestic");
});