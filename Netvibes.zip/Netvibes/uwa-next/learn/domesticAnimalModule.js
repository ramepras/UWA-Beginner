define("domesticAnimalModule", function() {
    function eat() {
        console.log('eat');
      }
      function sleep() {
        console.log('sleep');
      }
      return {
        eat: eat,
        sleep: sleep
      };
});