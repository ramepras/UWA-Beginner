function loadWiget() {
    require(['domestic'], function (domestic) {
        console.log(typeof domestic);
        var myWidget = {
            onLoad: function () {
                // Here we update the content of the widget body.
                myWidget.setBody("meow");
            },
            setBody: function (message) {
                widget.setBody({
                    tag: 'p',
                    text: 'Hello ' + message + '!'
                });
            },
        };
        widget.addEvent('onLoad', myWidget.onLoad);
      });
}